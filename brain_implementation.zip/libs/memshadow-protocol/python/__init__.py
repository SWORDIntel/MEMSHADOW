"""
DSMIL MEMSHADOW Protocol v2

Unified binary wire format for intra-node communications.
"""

from .dsmil_protocol import *
