"""MEMSHADOW Protocol Tests"""
